# V25 fixed storage and reinforced B trial

Open [the fixed-storage guide](FIXED-STORAGE/START-HERE.md).
