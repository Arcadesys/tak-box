# V25 reinforced B trial

Open [the reinforced-B-trial guide](REINFORCED-B-TRIAL/START-HERE.md).
