# V25 PIP fixed storage

Open [the fixed-storage guide](PIP-FIXED-STORAGE/START-HERE.md).
