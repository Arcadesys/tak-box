# V25 PIP fixed piece guides

Open [the fixed-storage guide](PIP-FIXED-GUIDES/START-HERE.md).
