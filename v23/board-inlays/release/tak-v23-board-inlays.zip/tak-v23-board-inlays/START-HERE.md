# V23 multicolour replacement boards

Start with [the guide](v23/board-inlays/README.md) and print the small trial first. Black/white projects use slots 1 and 2. Two silk accents use slots 3 and 4 and require both actual spool profiles and reslicing. The complete case is not included.
