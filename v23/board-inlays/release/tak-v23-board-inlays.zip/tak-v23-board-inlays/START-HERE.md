# V23 multicolour replacement boards

Start with [the guide](v23/board-inlays/README.md) and print the small trial first. Black/white projects use slots 1 and 2. Optional silk uses slot 3 and requires your actual spool profile and reslicing. The complete case is not included.
